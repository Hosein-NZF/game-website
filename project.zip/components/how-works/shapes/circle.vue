<template>
  <svg
    version="1.1"
    id="Layer_1"
    xmlns="http://www.w3.org/2000/svg"
    xmlns:xlink="http://www.w3.org/1999/xlink"
    x="0px"
    y="0px"
    viewBox="0 0 140 140"
    style="enable-background: new 0 0 140 140"
    xml:space="preserve"
    width="100px"
    height="100px"
  >
    <circle class="st0" cx="70" cy="66" r="64.5" />
    <path
      class="st1"
      d="M78,66c0,0.3-0.1,0.5-0.3,0.7C77.5,66.9,77.3,67,77,67H65.4l4.3,4.3c0.1,0.1,0.2,0.2,0.2,0.3
	C70,71.7,70,71.9,70,72c0,0.1,0,0.3-0.1,0.4c-0.1,0.1-0.1,0.2-0.2,0.3c-0.1,0.1-0.2,0.2-0.3,0.2C69.3,73,69.1,73,69,73
	s-0.3,0-0.4-0.1c-0.1-0.1-0.2-0.1-0.3-0.2l-6-6c-0.1-0.1-0.2-0.2-0.2-0.3C62,66.3,62,66.1,62,66c0-0.1,0-0.3,0.1-0.4
	c0.1-0.1,0.1-0.2,0.2-0.3l6-6c0.2-0.2,0.4-0.3,0.7-0.3c0.3,0,0.5,0.1,0.7,0.3c0.2,0.2,0.3,0.4,0.3,0.7c0,0.3-0.1,0.5-0.3,0.7
	L65.4,65H77c0.3,0,0.5,0.1,0.7,0.3C77.9,65.5,78,65.7,78,66z"
    />
  </svg>
</template>

<style scoped>
.st0 {
  fill: #0c0d21;
  stroke: #aef0ff;
  stroke-width: 3;
}
.st1 {
  fill-rule: evenodd;
  clip-rule: evenodd;
  fill: #aef0ff;
}
</style>

<style scoped>
@media (max-width: 800px) {
  svg {
    display: none;
  }
}
</style>