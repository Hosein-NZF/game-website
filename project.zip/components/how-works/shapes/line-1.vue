<template>
  <svg viewBox="0 0 486 200" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path
      d="M478 9C429.515 9 327.508 9 307.358 9C249.886 9 227.536 22.4797 226.471 90.2329C225.407 157.986 216.538 192.04 146.294 190.976C90.0994 190.124 31.3502 190.621 9 190.976"
      stroke="url(#paint0_linear_1256_3)"
      stroke-width="4"
      stroke-linejoin="round"
    />
    <circle
      cx="477"
      cy="9"
      r="7.5"
      fill="#54E0FF"
      stroke="#AEF0FF"
      stroke-width="3"
    />
    <circle
      cx="9"
      cy="191"
      r="7.5"
      fill="#54E0FF"
      stroke="#AEF0FF"
      stroke-width="3"
    />
    <defs>
      <linearGradient
        id="paint0_linear_1256_3"
        x1="9"
        y1="98.4576"
        x2="478"
        y2="98.4576"
        gradientUnits="userSpaceOnUse"
      >
        <stop stop-color="#4056A0" />
        <stop offset="0.510417" stop-color="#33B6E8" />
        <stop offset="1" stop-color="#4056A0" />
      </linearGradient>
    </defs>
  </svg>
</template>
<style scoped>
svg {
  width: 400px;
  height: 200px;
}
@media (max-width: 800px) {
  svg {
    width: 300px;
    height: 200px;
  }
}
</style>
