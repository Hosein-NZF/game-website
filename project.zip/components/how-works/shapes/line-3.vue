<template>
  <svg viewBox="0 0 280 425" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path
      d="M9.5 8.90909H151.58C233.921 8.90909 263 3.28106 263 57.0992L263 278L263 425"
      stroke="url(#paint0_linear_1256_4)"
      stroke-width="4"
      stroke-linejoin="round"
    />
    <circle
      cx="9"
      cy="9"
      r="7.5"
      transform="rotate(180 9 9)"
      fill="#54E0FF"
      stroke="#AEF0FF"
      stroke-width="3"
    />

    <defs>
      <linearGradient
        id="paint0_linear_1256_4"
        x1="263"
        y1="288.5"
        x2="17.4999"
        y2="-2.49998"
        gradientUnits="userSpaceOnUse"
      >
        <stop stop-color="#4056A0" />
        <stop offset="0.510417" stop-color="#33B6E8" />
        <stop offset="1" stop-color="#4056A0" />
      </linearGradient>
    </defs>
  </svg>
</template>

<style scoped>
svg {
  width: 265px;
  height: 300px;
}

@media (max-width: 800px) {
  svg {
    display: none;
  }
}
</style>
