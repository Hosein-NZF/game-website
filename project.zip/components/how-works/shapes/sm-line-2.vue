<template>
  <svg
    version="1.1"
    id="Layer_1"
    xmlns="http://www.w3.org/2000/svg"
    xmlns:xlink="http://www.w3.org/1999/xlink"
    x="0px"
    y="0px"
    height="300px"
    wight="200px"
    viewBox="0 0 155 360"
    style="enable-background: new 0 0 155 360"
    xml:space="preserve"
  >
    <linearGradient
      id="SVGID_1_"
      gradientUnits="userSpaceOnUse"
      x1="10.0359"
      y1="135.4899"
      x2="410.4049"
      y2="135.4899"
      gradientTransform="matrix(0 0.823 0.823 0 -34.5143 10.2182)"
    >
      <stop offset="0" style="stop-color: #4056a0" />
      <stop offset="0.5104" style="stop-color: #33b6e8" />
      <stop offset="1" style="stop-color: #4056a0" />
    </linearGradient>
    <path
      class="st0"
      d="M135.7,348c0-34.1,0-105.7,0-119.9c0-40.4-8.7-56.1-52.4-56.8c-43.7-0.7-65.7-7-65-56.3
	c0.5-39.5,0.2-80.8,0-96.5"
    />
    <circle class="st1" cx="17.9" cy="16.6" r="6.2" />
    <circle class="st1" cx="135.7" cy="348" r="6.2" />
  </svg>
</template>

<style scoped>
svg{
  transform: scaleX(-1);
}
.st0 {
  fill: none;
  stroke: url(#SVGID_1_);
  stroke-width: 3.2922;
  stroke-linejoin: round;
  stroke-miterlimit: 3.2922;
}
.st1 {
  fill: #54e0ff;
  stroke: #aef0ff;
  stroke-width: 2.4691;
  stroke-miterlimit: 3.2922;
}
</style>
