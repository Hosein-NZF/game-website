<template>
  <svg
    id="Layer_1"
    data-name="Layer 1"
    xmlns="http://www.w3.org/2000/svg"
    xmlns:xlink="http://www.w3.org/1999/xlink"
    viewBox="0 0 18.5 357.5"
  >
    <defs>
      <linearGradient
        id="linear-gradient"
        x1="-129.49"
        y1="140.99"
        x2="228.01"
        y2="140.99"
        gradientTransform="matrix(0, 1, 1, 0, -131, 129.5)"
        gradientUnits="userSpaceOnUse"
      >
        <stop offset="0" stop-color="#4056a0" />
        <stop offset="0.51" stop-color="#33b6e8" />
        <stop offset="1" stop-color="#4056a0" />
      </linearGradient>
    </defs>
    <path class="cls-1" d="M10,357.5V0" transform="translate(-0.5 0)" />
    <circle class="cls-2" cx="9.5" cy="9.5" r="7.5" />
    <circle class="cls-2" cx="9" cy="348.5" r="7.5" />
  </svg>
</template>

<style scoped>
svg {
  width: 8px;
  height: 275px;
}
.cls-1 {
  fill: none;
  stroke-width: 4px;
  stroke: url(#linear-gradient);
}
.cls-2 {
  fill: #54e0ff;
  stroke: #aef0ff;
  stroke-width: 3px;
}
</style>
