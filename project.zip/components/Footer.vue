<template>
  <v-footer class="justify-center" color="#4056A0">
      <strong class="copyright-text">©2022 Allright reserved</strong>
  </v-footer>
</template>

<script>
export default {
name:'Footer',
}
</script>

<style scoped>
.copyright-text{
    color: #fff;
    font-weight: normal;
    font-size: 14px;
    padding: 3px 0;
}
</style>