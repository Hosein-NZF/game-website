<template>
  <svg
    xmlns="http://www.w3.org/2000/svg"
    xmlns:xlink="http://www.w3.org/1999/xlink"
    version="1.1"
    id="Layer_1"
    x="0px"
    y="0px"
    viewBox="0 0 1440 611"
    style="enable-background: new 0 0 1440 611"
    xml:space="preserve"
  >
    <g>
      <linearGradient
        id="SVGID_1_"
        gradientUnits="userSpaceOnUse"
        x1="1002.7157"
        y1="302.4091"
        x2="915.0843"
        y2="454.1909"
        gradientTransform="matrix(1 0 0 -1 0 594)"
      >
        <stop offset="0" style="stop-color: #ae47ff; stop-opacity: 0.3" />
        <stop offset="1" style="stop-color: #ae47ff" />
      </linearGradient>
      <path
        class="st0"
        d="M871.3,215.7l43.8-75.9h87.6l43.8,75.9l-43.8,75.9h-87.6L871.3,215.7z"
      />

      <linearGradient
        id="SVGID_2_"
        gradientUnits="userSpaceOnUse"
        x1="1001.9095"
        y1="303.8055"
        x2="915.8906"
        y2="452.7945"
        gradientTransform="matrix(1 0 0 -1 0 594)"
      >
        <stop offset="0" style="stop-color: #ae47ff; stop-opacity: 0" />
        <stop offset="1" style="stop-color: #ae47ff; stop-opacity: 0.4" />
      </linearGradient>

      <linearGradient
        id="SVGID_3_"
        gradientUnits="userSpaceOnUse"
        x1="958.9"
        y1="272.6162"
        x2="958.9"
        y2="448.0097"
        gradientTransform="matrix(1 0 0 -1 0 576)"
      >
        <stop offset="0" style="stop-color: #6147ff" />
        <stop offset="0.5104" style="stop-color: #337be8" />
        <stop offset="1" style="stop-color: #6147ff" />
      </linearGradient>
      <path
        class="text-container_5"
        d="M915.9,290.2l-43-74.5l43-74.5h86l43,74.5l-43,74.5H915.9z"
      />
      <text class="shape-title text_7">Q4</text>
      <text class="shape-date text_8">2022</text>
      <path
        class="glass_1"
        d="M915.9,290.2l-43-74.5l43-74.5h86l43,74.5l-43,74.5H915.9z"
        @mouseover="hexagonHover($event.target)"
        @mouseleave="hexagonHoverSetOriginal($event.target)"
      />
    </g>
    <linearGradient
      id="SVGID_4_"
      gradientUnits="userSpaceOnUse"
      x1="62.0227"
      y1="366.45"
      x2="343.9774"
      y2="366.45"
      gradientTransform="matrix(1 0 0 1 0 -18)"
    >
      <stop offset="0" style="stop-color: #54e0ff" />
      <stop offset="0.151" style="stop-color: #5160e2; stop-opacity: 0.849" />
      <stop offset="1" style="stop-color: #414141; stop-opacity: 0" />
    </linearGradient>
    <polygon
      class="st2"
      points="301.1,275.4 216.5,275.4 215.7,276.8 179.3,213.8 101.5,213.8 62.6,281.1 101.4,348.4 62.6,415.7   101.5,483.1 179.3,483.1 215.6,420.2 216.5,421.9 301.1,421.9 343.4,348.6 "
    />
    <g>
      <linearGradient
        id="SVGID_5_"
        gradientUnits="userSpaceOnUse"
        x1="1235.9156"
        y1="168.8091"
        x2="1148.2844"
        y2="320.591"
        gradientTransform="matrix(1 0 0 -1 0 594)"
      >
        <stop offset="0" style="stop-color: #36ffdb; stop-opacity: 0.3" />
        <stop offset="1" style="stop-color: #36ffdb" />
      </linearGradient>
      <path
        class="st3"
        d="M1104.5,349.3l43.8-75.9h87.6l43.8,75.9l-43.8,75.9h-87.6L1104.5,349.3z"
      />

      <linearGradient
        id="SVGID_6_"
        gradientUnits="userSpaceOnUse"
        x1="1235.1094"
        y1="170.2055"
        x2="1149.0906"
        y2="319.1945"
        gradientTransform="matrix(1 0 0 -1 0 594)"
      >
        <stop offset="0" style="stop-color: #36ffdb; stop-opacity: 0.1" />
        <stop offset="1" style="stop-color: #36ffdb; stop-opacity: 0.4" />
      </linearGradient>

      <linearGradient
        id="SVGID_7_"
        gradientUnits="userSpaceOnUse"
        x1="1192.1"
        y1="138.9703"
        x2="1192.1"
        y2="314.3637"
        gradientTransform="matrix(1 0 0 -1 0 576)"
      >
        <stop offset="0" style="stop-color: #36ffdb" />
        <stop offset="0.5104" style="stop-color: #36ff62" />
        <stop offset="1" style="stop-color: #36ffdb" />
      </linearGradient>
      <path
        class="text-container_6"
        d="M1149.1,423.8l-43-74.5l43-74.5h86l43,74.5l-43,74.5H1149.1z"
      />
      <text class="shape-title text_9">Q5</text>
      <text class="shape-date text_10">2022</text>
      <path
        class="glass_1"
        d="M1149.1,423.8l-43-74.5l43-74.5h86l43,74.5l-43,74.5H1149.1z"
        @mouseover="hexagonHover($event.target)"
        @mouseleave="hexagonHoverSetOriginal($event.target)"
      />
    </g>
    <g>
      <linearGradient
        id="SVGID_8_"
        gradientUnits="userSpaceOnUse"
        x1="536.3157"
        y1="304.3091"
        x2="448.6843"
        y2="456.0909"
        gradientTransform="matrix(1 0 0 -1 0 594)"
      >
        <stop offset="0" style="stop-color: #379dd5; stop-opacity: 0.3" />
        <stop offset="1" style="stop-color: #379dd5" />
      </linearGradient>
      <path
        class="st5"
        d="M404.9,213.8l43.8-75.9h87.6l43.8,75.9l-43.8,75.9h-87.6L404.9,213.8z"
      />

      <linearGradient
        id="SVGID_9_"
        gradientUnits="userSpaceOnUse"
        x1="535.5095"
        y1="305.7055"
        x2="449.4905"
        y2="454.6945"
        gradientTransform="matrix(1 0 0 -1 0 594)"
      >
        <stop offset="0" style="stop-color: #379dd5; stop-opacity: 0.1" />
        <stop offset="1" style="stop-color: #379dd5; stop-opacity: 0.4" />
      </linearGradient>

      <linearGradient
        id="SVGID_10_"
        gradientUnits="userSpaceOnUse"
        x1="492.5"
        y1="274.4596"
        x2="492.5"
        y2="449.8531"
        gradientTransform="matrix(1 0 0 -1 0 576)"
      >
        <stop offset="0" style="stop-color: #4056a0" />
        <stop offset="0.5104" style="stop-color: #33b6e8" />
        <stop offset="1" style="stop-color: #4056a0" />
      </linearGradient>
      <path
        class="text-container_2"
        d="M449.5,288.3l-43-74.5l43-74.5h86l43,74.5l-43,74.5H449.5z"
      />
      <text class="shape-title text_3">Q2</text>
      <text class="shape-date text_4">2022</text>
      <path
        class="glass_1"
        d="M449.5,288.3l-43-74.5l43-74.5h86l43,74.5l-43,74.5H449.5z"
        @mouseover="hexagonHover($event.target)"
        @mouseleave="hexagonHoverSetOriginal($event.target)"
      />
    </g>
    <g>
      <path
        class="st7"
        d="M639,348.4l43.8-75.9h87.6l43.8,75.9l-43.8,75.9h-87.6L639,348.4z"
      />

      <linearGradient
        id="SVGID_11_"
        gradientUnits="userSpaceOnUse"
        x1="691.2108"
        y1="325.0526"
        x2="791.8087"
        y2="493.7547"
        gradientTransform="matrix(1 0 0 1 0 -36)"
      >
        <stop offset="0" style="stop-color: #ee48f3; stop-opacity: 0.4" />
        <stop offset="1" style="stop-color: #ee48f3; stop-opacity: 0" />
      </linearGradient>

      <linearGradient
        id="SVGID_12_"
        gradientUnits="userSpaceOnUse"
        x1="726.6"
        y1="139.892"
        x2="726.6"
        y2="315.2854"
        gradientTransform="matrix(1 0 0 -1 0 576)"
      >
        <stop offset="0" style="stop-color: #ee48f3" />
        <stop offset="0.5104" style="stop-color: #7448f3" />
        <stop offset="1" style="stop-color: #ee48f3" />
      </linearGradient>
      <path
        class="text-container_3"
        d="M683.6,422.9l-43-74.5l43-74.5h86l43,74.5l-43,74.5H683.6z"
      />
      <text class="shape-title text_5">Q3</text>
      <text class="shape-date text_6">2022</text>
      <path
        class="glass_1"
        d="M683.6,422.9l-43-74.5l43-74.5h86l43,74.5l-43,74.5H683.6z"
        @mouseover="hexagonHover($event.target)"
        @mouseleave="hexagonHoverSetOriginal($event.target)"
      />
    </g>
    <g class="st9">
      <linearGradient
        id="SVGID_13_"
        gradientUnits="userSpaceOnUse"
        x1="1348.7227"
        y1="363.1"
        x2="1505.4773"
        y2="363.1"
        gradientTransform="matrix(1 0 0 -1 0 576)"
      >
        <stop offset="0" style="stop-color: #54e0ff" />
        <stop offset="0.151" style="stop-color: #5160e2; stop-opacity: 0.849" />
        <stop offset="1" style="stop-color: #414141; stop-opacity: 0" />
      </linearGradient>
      <path
        class="st10"
        d="M1388.2,280.3l-38.9-67.4l38.9-67.4h77.8l38.9,67.4l-38.9,67.4H1388.2z"
      />
    </g>
    <g class="st9">
      <linearGradient
        id="SVGID_14_"
        gradientUnits="userSpaceOnUse"
        x1="1228.9227"
        y1="430.4"
        x2="1385.6774"
        y2="430.4"
        gradientTransform="matrix(1 0 0 -1 0 576)"
      >
        <stop offset="0" style="stop-color: #54e0ff" />
        <stop offset="0.151" style="stop-color: #5160e2; stop-opacity: 0.849" />
        <stop offset="1" style="stop-color: #414141; stop-opacity: 0" />
      </linearGradient>
      <path
        class="st11"
        d="M1268.4,213l-38.9-67.4l38.9-67.4h77.8l38.9,67.4l-38.9,67.4H1268.4z"
      />
    </g>
    <g class="st9">
      <linearGradient
        id="SVGID_15_"
        gradientUnits="userSpaceOnUse"
        x1="62.9227"
        y1="430.4"
        x2="219.6773"
        y2="430.4"
        gradientTransform="matrix(1 0 0 -1 0 576)"
      >
        <stop offset="0" style="stop-color: #54e0ff" />
        <stop offset="0.151" style="stop-color: #5160e2; stop-opacity: 0.849" />
        <stop offset="1" style="stop-color: #414141; stop-opacity: 0" />
      </linearGradient>
      <path
        class="st12"
        d="M102.4,213l-38.9-67.4l38.9-67.4h77.8l38.9,67.4L180.2,213H102.4z"
      />
    </g>
    <linearGradient
      id="SVGID_16_"
      gradientUnits="userSpaceOnUse"
      x1="405.6226"
      y1="254.35"
      x2="815.877"
      y2="254.35"
      gradientTransform="matrix(1 0 0 1 0 -36)"
    >
      <stop offset="0" style="stop-color: #54e0ff" />
      <stop offset="0.151" style="stop-color: #5160e2; stop-opacity: 0.849" />
      <stop offset="1" style="stop-color: #414141; stop-opacity: 0" />
    </linearGradient>
    <polygon
      class="st13"
      points="771.6,273.1 684,273.1 683.4,274.2 648.5,213.8 687.3,146.6 648.4,79.2 570.6,79.2 537.3,137   536.1,137 569.3,79.3 530.5,11.9 452.7,11.9 413.8,79.3 448.6,139.6 406.2,213 449.5,288 414.7,348.4 453.6,415.8 531.4,415.8   570.3,348.4 536.1,289.1 536.4,289.1 570.6,348.5 640.4,348.5 640.2,349 684,424.8 771.6,424.8 815.3,349 "
    />
    <linearGradient
      id="SVGID_17_"
      gradientUnits="userSpaceOnUse"
      x1="531.1227"
      y1="295.4"
      x2="1044.4773"
      y2="295.4"
      gradientTransform="matrix(1 0 0 -1 0 612)"
    >
      <stop offset="0" style="stop-color: #54e0ff" />
      <stop offset="0.151" style="stop-color: #5160e2; stop-opacity: 0.849" />
      <stop offset="1" style="stop-color: #414141; stop-opacity: 0" />
    </linearGradient>
    <polygon
      class="st14"
      points="1000.9,289.4 1043.9,214.9 1000.9,140.4 916.4,140.4 881.6,80.1 803.8,80.1 764.9,147.5 803.7,214.8   769.1,274.8 769,274.5 803.5,214.8 764.6,147.4 686.8,147.4 647.9,214.8 682.3,274.5 639.8,348.3 570.6,348.3 531.7,415.7   570.6,483.1 648.4,483.1 683.1,423 685,423 648.8,485.7 687.7,553.1 765.5,553.1 804.4,485.7 768.2,423 768.6,423 803.8,484   881.6,484 920.5,416.6 881.7,349.3 916.2,289.4 "
    />
    <linearGradient
      id="SVGID_18_"
      gradientUnits="userSpaceOnUse"
      x1="871.8224"
      y1="342.2"
      x2="1278.9773"
      y2="342.2"
      gradientTransform="matrix(1 0 0 -1 0 594)"
    >
      <stop offset="0" style="stop-color: #54e0ff" />
      <stop offset="0.151" style="stop-color: #5160e2; stop-opacity: 0.849" />
      <stop offset="1" style="stop-color: #414141; stop-opacity: 0" />
    </linearGradient>
    <polygon
      class="st15"
      points="1235.6,275.1 1149.8,275.1 1149.7,275.2 1114.9,214.8 1153.7,147.5 1114.8,80.1 1037,80.1   1001.1,142.3 1000.7,141.7 915.2,141.7 872.4,215.7 915.1,289.5 881.1,348.4 920,415.8 997.8,415.8 1036.6,348.6 1037,349.4   1107.1,349.4 1149.8,423.5 1235.6,423.5 1278.4,349.3 "
    />
    <g class="st9">
      <linearGradient
        id="SVGID_19_"
        gradientUnits="userSpaceOnUse"
        x1="1348.7227"
        y1="228.5"
        x2="1505.4773"
        y2="228.5"
        gradientTransform="matrix(1 0 0 -1 0 576)"
      >
        <stop offset="0" style="stop-color: #54e0ff" />
        <stop offset="0.151" style="stop-color: #5160e2; stop-opacity: 0.849" />
        <stop offset="1" style="stop-color: #414141; stop-opacity: 0" />
      </linearGradient>
      <path
        class="st16"
        d="M1388.2,414.9l-38.9-67.4l38.9-67.4h77.8l38.9,67.4l-38.9,67.4H1388.2z"
      />
    </g>
    <g class="st9">
      <linearGradient
        id="SVGID_20_"
        gradientUnits="userSpaceOnUse"
        x1="879.5227"
        y1="92.1"
        x2="1036.2772"
        y2="92.1"
        gradientTransform="matrix(1 0 0 -1 0 576)"
      >
        <stop offset="0" style="stop-color: #54e0ff" />
        <stop offset="0.151" style="stop-color: #5160e2; stop-opacity: 0.849" />
        <stop offset="1" style="stop-color: #414141; stop-opacity: 0" />
      </linearGradient>
      <path
        class="st17"
        d="M919,551.3l-38.9-67.4l38.9-67.4h77.8l38.9,67.4l-38.9,67.4H919z"
      />
    </g>
    <linearGradient
      id="SVGID_21_"
      gradientUnits="userSpaceOnUse"
      x1="174.0227"
      y1="312.85"
      x2="576.6772"
      y2="312.85"
      gradientTransform="matrix(1 0 0 -1 0 594)"
    >
      <stop offset="0" style="stop-color: #54e0ff" />
      <stop offset="0.151" style="stop-color: #5160e2; stop-opacity: 0.849" />
      <stop offset="1" style="stop-color: #414141; stop-opacity: 0" />
    </linearGradient>
    <polygon
      class="st18"
      points="533.8,287.8 576.1,214.5 533.8,141.2 451.1,141.2 415.2,79.2 337.4,79.2 298.6,146.6 337.4,213.8   337,214.6 298.2,147.4 220.4,147.4 181.5,214.8 216.6,275.7 174.6,348.5 216.8,421.6 301.1,421.6 301.5,420.9 337.4,483.1   415.2,483.1 454.1,415.7 415.3,348.4 450.4,287.8 "
    />
    <linearGradient
      id="SVGID_22_"
      gradientUnits="userSpaceOnUse"
      x1="998.4227"
      y1="350.8"
      x2="1388.3773"
      y2="350.8"
      gradientTransform="matrix(1 0 0 1 0 -36)"
    >
      <stop offset="0" style="stop-color: #54e0ff" />
      <stop offset="0.151" style="stop-color: #5160e2; stop-opacity: 0.849" />
      <stop offset="1" style="stop-color: #414141; stop-opacity: 0" />
    </linearGradient>
    <polygon
      class="st19"
      points="1387.8,279.3 1348.9,211.9 1271.1,211.9 1234.1,276.2 1233,276.2 1268.9,213.8 1230,146.5   1152.2,146.5 1113.3,213.8 1149.6,276.8 1108.4,348.3 1037.9,348.3 999,415.7 1037.9,483.1 1115.7,483.1 1150.5,422.9 1234.8,422.9   1236.1,420.6 1271.1,481.2 1348.9,481.2 1387.8,413.9 1349,346.6 "
    />
    <linearGradient
      id="SVGID_23_"
      gradientUnits="userSpaceOnUse"
      x1="535.6988"
      y1="256.9308"
      x2="639.4897"
      y2="256.9308"
      gradientTransform="matrix(1 0 0 -1 0 576)"
    >
      <stop offset="0" style="stop-color: #3f67ad" />
      <stop offset="0.5104" style="stop-color: #3733e8" />
      <stop offset="1" style="stop-color: #8f48f3" />
    </linearGradient>
    <path class="st20" d="M535.8,289l35,59.4h68.7" />
    <linearGradient
      id="SVGID_24_"
      gradientUnits="userSpaceOnUse"
      x1="449.2598"
      y1="257.1768"
      x2="345.9294"
      y2="257.1768"
      gradientTransform="matrix(1 0 0 -1 0 576)"
    >
      <stop offset="0" style="stop-color: #3f67ad" />
      <stop offset="0.5104" style="stop-color: #33b2e8" />
      <stop offset="1" style="stop-color: #ff7036" />
    </linearGradient>
    <path class="st21" d="M449.2,288.5l-34.8,59.9H346" />
    <linearGradient
      id="SVGID_25_"
      gradientUnits="userSpaceOnUse"
      x1="1001.6164"
      y1="256.2824"
      x2="1105.4071"
      y2="256.2824"
      gradientTransform="matrix(1 0 0 -1 0 576)"
    >
      <stop offset="0" style="stop-color: #6147ff" />
      <stop offset="0.5104" style="stop-color: #337be8" />
      <stop offset="1" style="stop-color: #36ff7b" />
    </linearGradient>
    <path class="st22" d="M1001.7,289.4l35.5,59.9h68.2" />
    <linearGradient
      id="SVGID_26_"
      gradientUnits="userSpaceOnUse"
      x1="846.5191"
      y1="375.7418"
      x2="793.8323"
      y2="287.499"
      gradientTransform="matrix(1 0 0 -1 0 576)"
    >
      <stop offset="0" style="stop-color: #4d70ed" />
      <stop offset="0.5104" style="stop-color: #3a46d3" />
      <stop offset="1" style="stop-color: #dd49f2" />
    </linearGradient>
    <path class="st23" d="M872.3,215.8l-69-0.4l-33.4,58.8" />
    <linearGradient
      id="SVGID_27_"
      gradientUnits="userSpaceOnUse"
      x1="578.5"
      y1="249.8"
      x2="647.9"
      y2="249.8"
      gradientTransform="matrix(1 0 0 1 0 -36)"
    >
      <stop offset="0" style="stop-color: #54e0ff" />
      <stop offset="0.151" style="stop-color: #5160e2; stop-opacity: 0.849" />
      <stop offset="1" style="stop-color: #414141; stop-opacity: 0" />
    </linearGradient>
    <line class="st24" x1="578.5" y1="213.8" x2="647.9" y2="213.8" />
    <linearGradient
      id="SVGID_28_"
      gradientUnits="userSpaceOnUse"
      x1="812.6"
      y1="384.4"
      x2="881.1"
      y2="384.4"
      gradientTransform="matrix(1 0 0 1 0 -36)"
    >
      <stop offset="0" style="stop-color: #54e0ff" />
      <stop offset="0.151" style="stop-color: #5160e2; stop-opacity: 0.849" />
      <stop offset="1" style="stop-color: #414141; stop-opacity: 0" />
    </linearGradient>
    <line class="st25" x1="812.6" y1="348.4" x2="881.1" y2="348.4" />
    <linearGradient
      id="SVGID_29_"
      gradientUnits="userSpaceOnUse"
      x1="1044.9"
      y1="251.7"
      x2="1112.4"
      y2="251.7"
      gradientTransform="matrix(1 0 0 1 0 -36)"
    >
      <stop offset="0" style="stop-color: #54e0ff" />
      <stop offset="0.151" style="stop-color: #5160e2; stop-opacity: 0.849" />
      <stop offset="1" style="stop-color: #414141; stop-opacity: 0" />
    </linearGradient>
    <line class="st26" x1="1044.9" y1="215.7" x2="1112.4" y2="215.7" />
    <linearGradient
      id="SVGID_30_"
      gradientUnits="userSpaceOnUse"
      x1="1279.587"
      y1="384.4"
      x2="1349.313"
      y2="384.4"
      gradientTransform="matrix(1 0 0 1 0 -36)"
    >
      <stop offset="0" style="stop-color: #54e0ff" />
      <stop offset="0.151" style="stop-color: #5160e2; stop-opacity: 0.849" />
      <stop offset="1" style="stop-color: #414141; stop-opacity: 0" />
    </linearGradient>
    <line class="st27" x1="1279.6" y1="349.3" x2="1349.3" y2="347.5" />
    <linearGradient
      id="SVGID_31_"
      gradientUnits="userSpaceOnUse"
      x1="301.7686"
      y1="279.3264"
      x2="406.0539"
      y2="279.3264"
      gradientTransform="matrix(1 0 0 1 0 -36)"
    >
      <stop offset="0" style="stop-color: #54e0ff" />
      <stop offset="0.151" style="stop-color: #5160e2; stop-opacity: 0.849" />
      <stop offset="1" style="stop-color: #414141; stop-opacity: 0" />
    </linearGradient>
    <polyline class="st28" points="302.2,273.9 337.4,213.8 406.2,213 " />
    <linearGradient
      id="SVGID_32_"
      gradientUnits="userSpaceOnUse"
      x1="101.4"
      y1="366.4"
      x2="174.6"
      y2="366.4"
      gradientTransform="matrix(1 0 0 1 0 -18)"
    >
      <stop offset="0" style="stop-color: #54e0ff" />
      <stop offset="0.151" style="stop-color: #5160e2; stop-opacity: 0.849" />
      <stop offset="1" style="stop-color: #414141; stop-opacity: 0" />
    </linearGradient>
    <line class="st29" x1="101.4" y1="348.4" x2="174.6" y2="348.4" />
    <g class="st9">
      <linearGradient
        id="SVGID_33_"
        gradientUnits="userSpaceOnUse"
        x1="-54.6773"
        y1="363"
        x2="102.0773"
        y2="363"
        gradientTransform="matrix(1 0 0 -1 0 576)"
      >
        <stop offset="0" style="stop-color: #54e0ff" />
        <stop offset="0.151" style="stop-color: #5160e2; stop-opacity: 0.849" />
        <stop offset="1" style="stop-color: #414141; stop-opacity: 0" />
      </linearGradient>
      <path
        class="st30"
        d="M-15.2,280.4L-54.1,213l38.9-67.4h77.8l38.9,67.4l-38.9,67.4H-15.2z"
      />
    </g>
    <g class="st9">
      <linearGradient
        id="SVGID_34_"
        gradientUnits="userSpaceOnUse"
        x1="-54.6773"
        y1="227.6"
        x2="102.0773"
        y2="227.6"
        gradientTransform="matrix(1 0 0 -1 0 576)"
      >
        <stop offset="0" style="stop-color: #54e0ff" />
        <stop offset="0.151" style="stop-color: #5160e2; stop-opacity: 0.849" />
        <stop offset="1" style="stop-color: #414141; stop-opacity: 0" />
      </linearGradient>
      <path
        class="st31"
        d="M-15.2,415.8l-38.9-67.4l38.9-67.4h77.8l38.9,67.4l-38.9,67.4H-15.2z"
      />
    </g>
    <g class="st9">
      <linearGradient
        id="SVGID_35_"
        gradientUnits="userSpaceOnUse"
        x1="223.8814"
        y1="-318.762"
        x2="380.6758"
        y2="-318.762"
        gradientTransform="matrix(-0.5046 0.8634 0.8634 0.5046 451.3989 383.8599)"
      >
        <stop offset="0" style="stop-color: #54e0ff" />
        <stop offset="0.151" style="stop-color: #5160e2; stop-opacity: 0.849" />
        <stop offset="1" style="stop-color: #414141; stop-opacity: 0" />
      </linearGradient>
      <path
        class="st32"
        d="M-14.9,416.4l77.8,0.4l38.5,67.6l-39.2,67.2l-77.8-0.4l-38.5-67.6L-14.9,416.4z"
      />
    </g>
    <g>
      <linearGradient
        id="SVGID_36_"
        gradientUnits="userSpaceOnUse"
        x1="303.1156"
        y1="169.709"
        x2="215.4844"
        y2="321.491"
        gradientTransform="matrix(1 0 0 -1 0 594)"
      >
        <stop offset="0" style="stop-color: #ff4e36; stop-opacity: 0.3" />
        <stop offset="1" style="stop-color: #ff4e36" />
      </linearGradient>
      <path
        class="st33"
        d="M171.7,348.4l43.8-75.9h87.6l43.8,75.9l-43.8,75.9h-87.6L171.7,348.4z"
      />

      <linearGradient
        id="SVGID_37_"
        gradientUnits="userSpaceOnUse"
        x1="302.3094"
        y1="171.1054"
        x2="216.2906"
        y2="320.0946"
        gradientTransform="matrix(1 0 0 -1 0 594)"
      >
        <stop offset="0" style="stop-color: #ff4e36; stop-opacity: 0.1" />
        <stop offset="1" style="stop-color: #ff4e36; stop-opacity: 0.4" />
      </linearGradient>

      <linearGradient
        id="SVGID_38_"
        gradientUnits="userSpaceOnUse"
        x1="259.3"
        y1="139.892"
        x2="259.3"
        y2="315.2854"
        gradientTransform="matrix(1 0 0 -1 0 576)"
      >
        <stop offset="0" style="stop-color: #ff4e36" />
        <stop offset="0.5104" style="stop-color: #ff7236" />
        <stop offset="1" style="stop-color: #ff4e36" />
      </linearGradient>
      <path
        class="text-container_1"
        d="M216.3,422.9l-43-74.5l43-74.5h86l43,74.5l-43,74.5H216.3z"
      />
      <text class="shape-title text_1">Q1</text>
      <text class="shape-date text_2">2022</text>
      <path
        class="glass_1"
        d="M216.3,422.9l-43-74.5l43-74.5h86l43,74.5l-43,74.5H216.3z"
        @mouseover="hexagonHover($event.target)"
        @mouseleave="hexagonHoverSetOriginal($event.target)"
      />
    </g>
  </svg>
</template>

<script>
export default {
  name: "Hexagons",
  data() {
    return {
      latestMatrix: null,
    };
  },
  methods: {
    hexagonHover(el) {
      let parent = el.parentElement;
      let titleEl = parent.querySelector(".shape-title");
      let dateEl = parent.querySelector(".shape-date");

      this.latestMatrix = window.getComputedStyle(titleEl).transform;
      Object.assign(titleEl.style, {
        transform: `${this.latestMatrix} translateY(25px)`,
        "font-size": "55px",
      });
      dateEl.style.opacity = "0";
    },
    hexagonHoverSetOriginal(el) {
      let parent = el.parentElement;
      let titleEl = parent.querySelector(".shape-title");
      let dateEl = parent.querySelector(".shape-date");

      Object.assign(titleEl.style, {
        transform: `${this.latestMatrix}`,
        "font-size": "34px",
      });

      dateEl.style.opacity = "1";
    },
  },
};
</script>

<style>
.st0 {
  fill: url(#SVGID_1_);
  fill-opacity: 8e-2;
}
.text-container_5 {
  fill: url(#SVGID_2_);
  stroke: url(#SVGID_3_);
  stroke-width: 3;
}
.st2 {
  fill: none;
  stroke: url(#SVGID_4_);
}
.st3 {
  fill: url(#SVGID_5_);
  fill-opacity: 8e-2;
}
.text-container_6 {
  fill: url(#SVGID_6_);
  stroke: url(#SVGID_7_);
  stroke-width: 3;
}
.st5 {
  fill: url(#SVGID_8_);
  fill-opacity: 8e-2;
}
.text-container_2 {
  fill: url(#SVGID_9_);
  stroke: url(#SVGID_10_);
  stroke-width: 3;
}
.st7 {
  fill: #ffffff;
  fill-opacity: 8e-2;
}
.text-container_3 {
  fill: url(#SVGID_11_);
  stroke: url(#SVGID_12_);
  stroke-width: 3;
}
.st9 {
  opacity: 0.5;
}
.st10 {
  fill: none;
  stroke: url(#SVGID_13_);
}
.st11 {
  fill: none;
  stroke: url(#SVGID_14_);
}
.st12 {
  fill: none;
  stroke: url(#SVGID_15_);
}
.st13 {
  fill: none;
  stroke: url(#SVGID_16_);
}
.st14 {
  fill: none;
  stroke: url(#SVGID_17_);
}
.st15 {
  fill: none;
  stroke: url(#SVGID_18_);
}
.st16 {
  fill: none;
  stroke: url(#SVGID_19_);
}
.st17 {
  fill: none;
  stroke: url(#SVGID_20_);
}
.st18 {
  fill: none;
  stroke: url(#SVGID_21_);
}
.st19 {
  fill: none;
  stroke: url(#SVGID_22_);
}
.st20 {
  fill: none;
  stroke: url(#SVGID_23_);
  stroke-width: 3;
}
.st21 {
  fill: none;
  stroke: url(#SVGID_24_);
  stroke-width: 3;
}
.st22 {
  fill: none;
  stroke: url(#SVGID_25_);
  stroke-width: 3;
}
.st23 {
  fill: none;
  stroke: url(#SVGID_26_);
  stroke-width: 3;
}
.st24 {
  fill: none;
  stroke: url(#SVGID_27_);
}
.st25 {
  fill: none;
  stroke: url(#SVGID_28_);
}
.st26 {
  fill: none;
  stroke: url(#SVGID_29_);
}
.st27 {
  fill: none;
  stroke: url(#SVGID_30_);
}
.st28 {
  fill: none;
  stroke: url(#SVGID_31_);
}
.st29 {
  fill: none;
  stroke: url(#SVGID_32_);
}
.st30 {
  fill: none;
  stroke: url(#SVGID_33_);
}
.st31 {
  fill: none;
  stroke: url(#SVGID_34_);
}
.st32 {
  fill: none;
  stroke: url(#SVGID_35_);
}
.st33 {
  fill: url(#SVGID_36_);
  fill-opacity: 8e-2;
}
.text-container_1 {
  fill: url(#SVGID_37_);
  stroke: url(#SVGID_38_);
  stroke-width: 3;
}

text[class*="text"] {
  font-weight: bold;
  font-size: 34px;
  fill: #ffffff;
  transition: all 300ms;
}
text.shape-date{
  transition: all 300ms;
}
[class*="glass"] {
  fill: transparent;
  cursor: pointer;
}
.text_1 {
  transform: matrix(1, 0, 0, 1, 236.5036, 336.8004);
}
.text_2 {
  transform: matrix(1, 0, 0, 1, 222.7755, 380.4);
}
.text_3 {
  transform: matrix(1, 0, 0, 1, 472.0999, 200.5505);
}
.text_4 {
  transform: matrix(1, 0, 0, 1, 458.3718, 244.1502);
}
.text_5 {
  transform: matrix(1, 0, 0, 1, 706.4279, 334.5005);
}
.text_6 {
  transform: matrix(1, 0, 0, 1, 692.6998, 378.1002);
}
.text_7 {
  transform: matrix(1, 0, 0, 1, 936.9639, 205.0579);
}
.text_8 {
  transform: matrix(1, 0, 0, 1, 923.2357, 248.6575);
}
.text_9 {
  transform: matrix(1, 0, 0, 1, 1171.6139, 336.5005);
}
.text_10 {
  transform: matrix(1, 0, 0, 1, 1157.8857, 380.1002);
}



</style>
