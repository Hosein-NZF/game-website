<template>
  <svg
    xmlns="http://www.w3.org/2000/svg"
    xmlns:xlink="http://www.w3.org/1999/xlink"
    id="Layer_1"
    data-name="Layer 1"
    viewBox="0 0 260.29 674.31"
  >
    <defs>
      <linearGradient
        id="Fading_Sky"
        x1="41.61"
        y1="45.86"
        x2="129.03"
        y2="45.86"
        gradientTransform="matrix(-1, 0, 0, 1, 260.29, 29.79)"
        gradientUnits="userSpaceOnUse"
      >
        <stop offset="0" stop-color="#2484c6" />
        <stop offset="1" stop-color="#2484c6" stop-opacity="0" />
      </linearGradient>
      <linearGradient
        id="Fading_Sky-2"
        x1="41.61"
        y1="120.57"
        x2="129.03"
        y2="120.57"
        xlink:href="#Fading_Sky"
      />
      <linearGradient
        id="Fading_Sky-3"
        x1="106.87"
        y1="157.92"
        x2="194.29"
        y2="157.92"
        xlink:href="#Fading_Sky"
      />
      <linearGradient
        id="Fading_Sky-4"
        x1="106.87"
        y1="232.95"
        x2="194.29"
        y2="232.95"
        xlink:href="#Fading_Sky"
      />
      <linearGradient
        id="Fading_Sky-5"
        x1="41.61"
        y1="269.59"
        x2="129.03"
        y2="269.59"
        xlink:href="#Fading_Sky"
      />
      <linearGradient
        id="Fading_Sky-6"
        x1="41.86"
        y1="344.43"
        x2="129.28"
        y2="344.43"
        xlink:href="#Fading_Sky"
      />
      <linearGradient
        id="Fading_Sky-7"
        x1="41.86"
        y1="419.13"
        x2="129.28"
        y2="419.13"
        xlink:href="#Fading_Sky"
      />
      <linearGradient
        id="Fading_Sky-8"
        x1="107.12"
        y1="381.78"
        x2="194.54"
        y2="381.78"
        xlink:href="#Fading_Sky"
      />
      <linearGradient
        id="Fading_Sky-9"
        x1="107.12"
        y1="456.49"
        x2="194.54"
        y2="456.49"
        xlink:href="#Fading_Sky"
      />
      <linearGradient
        id="Fading_Sky-10"
        x1="41.86"
        y1="494.61"
        x2="129.28"
        y2="494.61"
        xlink:href="#Fading_Sky"
      />
      <linearGradient
        id="Fading_Sky-11"
        x1="41.86"
        y1="569.32"
        x2="129.28"
        y2="569.32"
        xlink:href="#Fading_Sky"
      />
      <linearGradient
        id="Fading_Sky-12"
        x1="107.12"
        y1="531.96"
        x2="194.54"
        y2="531.96"
        xlink:href="#Fading_Sky"
      />
      <linearGradient
        id="Fading_Sky-13"
        x1="111.11"
        y1="528.72"
        x2="67.41"
        y2="453.01"
        gradientTransform="matrix(0.5, -0.87, -0.87, -0.5, 489.93, 959.2)"
        xlink:href="#Fading_Sky"
      />
      <linearGradient
        id="Fading_Sky-14"
        x1="170.91"
        y1="44.94"
        x2="258.32"
        y2="44.94"
        xlink:href="#Fading_Sky"
      />
      <linearGradient
        id="Fading_Sky-15"
        x1="172.22"
        y1="120.73"
        x2="259.63"
        y2="120.73"
        xlink:href="#Fading_Sky"
      />
      <linearGradient
        id="Fading_Sky-16"
        x1="171.56"
        y1="195.21"
        x2="258.98"
        y2="195.21"
        xlink:href="#Fading_Sky"
      />
      <linearGradient
        id="Fading_Sky-17"
        x1="172.87"
        y1="269.69"
        x2="260.29"
        y2="269.69"
        xlink:href="#Fading_Sky"
      />
      <linearGradient
        id="Fading_Sky-18"
        x1="172.22"
        y1="344.18"
        x2="259.63"
        y2="344.18"
        xlink:href="#Fading_Sky"
      />
      <linearGradient
        id="Fading_Sky-19"
        x1="172.22"
        y1="418.66"
        x2="259.63"
        y2="418.66"
        xlink:href="#Fading_Sky"
      />
      <linearGradient
        id="Fading_Sky-20"
        x1="171.18"
        y1="493.61"
        x2="258.59"
        y2="493.61"
        xlink:href="#Fading_Sky"
      />
      <linearGradient
        id="Fading_Sky-21"
        x1="172.48"
        y1="569.4"
        x2="259.9"
        y2="569.4"
        xlink:href="#Fading_Sky"
      />
      <linearGradient
        id="Fading_Sky-22"
        x1="108.08"
        y1="127.77"
        x2="130.51"
        y2="127.77"
        gradientTransform="matrix(0.5, -0.87, -0.87, -0.5, 193.71, 186.89)"
        xlink:href="#Fading_Sky"
      />
      <linearGradient
        id="Fading_Sky-23"
        x1="23.71"
        y1="89.77"
        x2="1.28"
        y2="89.77"
        gradientTransform="matrix(-1, 0, 0, 1, 90.2, -70.85)"
        xlink:href="#Fading_Sky"
      />
      <linearGradient
        id="Fading_Sky-24"
        x1="-404.32"
        y1="-236.19"
        x2="-393.1"
        y2="-255.62"
        gradientTransform="matrix(0.5, -0.87, -0.87, -0.5, 193.71, 186.89)"
        xlink:href="#Fading_Sky"
      />
      <linearGradient
        id="linear-gradient"
        x1="172.85"
        y1="127.25"
        x2="127.72"
        y2="49.08"
        gradientTransform="matrix(-1, 0, 0, 1, 259.71, -6)"
        gradientUnits="userSpaceOnUse"
      >
        <stop offset="0" stop-color="#77cbc0" stop-opacity="0.3" />
        <stop offset="1" stop-color="#77cbc0" />
      </linearGradient>
      <linearGradient
        id="linear-gradient-2"
        x1="172.43"
        y1="126.53"
        x2="128.13"
        y2="49.8"
        gradientTransform="matrix(-1, 0, 0, 1, 259.71, -6)"
        gradientUnits="userSpaceOnUse"
      >
        <stop offset="0" stop-color="#77cbc0" stop-opacity="0.1" />
        <stop offset="1" stop-color="#77cbc0" stop-opacity="0.4" />
      </linearGradient>
      <linearGradient
        id="linear-gradient-3"
        x1="150.28"
        y1="152.19"
        x2="150.28"
        y2="60.18"
        gradientTransform="matrix(-1, 0, 0, 1, 259.71, -24)"
        gradientUnits="userSpaceOnUse"
      >
        <stop offset="0" stop-color="#77cbc0" />
        <stop offset="0.51" stop-color="#78c14a" />
        <stop offset="1" stop-color="#77cbc0" />
      </linearGradient>
      <linearGradient
        id="linear-gradient-4"
        x1="107.44"
        y1="239.39"
        x2="63.33"
        y2="162.99"
        gradientTransform="matrix(-1, 0, 0, 1, 259.71, -6)"
        gradientUnits="userSpaceOnUse"
      >
        <stop offset="0" stop-color="#875ca6" stop-opacity="0.3" />
        <stop offset="1" stop-color="#875ca6" />
      </linearGradient>
      <linearGradient
        id="linear-gradient-5"
        x1="107.04"
        y1="238.69"
        x2="63.74"
        y2="163.7"
        gradientTransform="matrix(-1, 0, 0, 1, 259.71, -6)"
        gradientUnits="userSpaceOnUse"
      >
        <stop offset="0" stop-color="#875ca6" stop-opacity="0" />
        <stop offset="1" stop-color="#875ca6" stop-opacity="0.4" />
      </linearGradient>
      <linearGradient
        id="linear-gradient-6"
        x1="85.39"
        y1="264.19"
        x2="85.39"
        y2="174.18"
        gradientTransform="matrix(-1, 0, 0, 1, 259.71, -24)"
        gradientUnits="userSpaceOnUse"
      >
        <stop offset="0" stop-color="#5e5da9" />
        <stop offset="0.51" stop-color="#4876ba" />
        <stop offset="1" stop-color="#5e5da9" />
      </linearGradient>
      <linearGradient
        id="linear-gradient-7"
        x1="132.08"
        y1="380.04"
        x2="184.69"
        y2="291.82"
        gradientTransform="translate(259.71 656) rotate(180)"
        gradientUnits="userSpaceOnUse"
      >
        <stop offset="0" stop-color="#b861a6" stop-opacity="0.4" />
        <stop offset="1" stop-color="#b861a6" stop-opacity="0" />
      </linearGradient>
      <linearGradient
        id="linear-gradient-8"
        x1="150.59"
        y1="377.68"
        x2="150.59"
        y2="284.32"
        gradientTransform="matrix(-1, 0, 0, 1, 259.71, -24)"
        gradientUnits="userSpaceOnUse"
      >
        <stop offset="0" stop-color="#b861a6" />
        <stop offset="0.51" stop-color="#685ca8" />
        <stop offset="1" stop-color="#b861a6" />
      </linearGradient>
      <linearGradient
        id="linear-gradient-9"
        x1="108.02"
        y1="465.78"
        x2="63.07"
        y2="387.92"
        gradientTransform="matrix(-1, 0, 0, 1, 259.71, -6)"
        gradientUnits="userSpaceOnUse"
      >
        <stop offset="0" stop-color="#389dd6" stop-opacity="0.3" />
        <stop offset="1" stop-color="#389dd6" />
      </linearGradient>
      <linearGradient
        id="linear-gradient-10"
        x1="107.61"
        y1="465.06"
        x2="63.48"
        y2="388.64"
        gradientTransform="matrix(-1, 0, 0, 1, 259.71, -6)"
        gradientUnits="userSpaceOnUse"
      >
        <stop offset="0" stop-color="#389dd6" stop-opacity="0.1" />
        <stop offset="1" stop-color="#389dd6" stop-opacity="0.4" />
      </linearGradient>
      <linearGradient
        id="linear-gradient-11"
        x1="85.55"
        y1="490.7"
        x2="85.55"
        y2="399.05"
        gradientTransform="matrix(-1, 0, 0, 1, 259.71, -24)"
        gradientUnits="userSpaceOnUse"
      >
        <stop offset="0" stop-color="#4156a0" />
        <stop offset="0.51" stop-color="#36b7e8" />
        <stop offset="1" stop-color="#4156a0" />
      </linearGradient>
      <linearGradient
        id="linear-gradient-12"
        x1="173.8"
        y1="577.25"
        x2="129.11"
        y2="499.84"
        gradientTransform="matrix(-1, 0, 0, 1, 259.71, -6)"
        gradientUnits="userSpaceOnUse"
      >
        <stop offset="0" stop-color="#f0523c" stop-opacity="0.3" />
        <stop offset="1" stop-color="#f0523c" />
      </linearGradient>
      <linearGradient
        id="linear-gradient-13"
        x1="173.39"
        y1="576.54"
        x2="129.52"
        y2="500.56"
        gradientTransform="matrix(-1, 0, 0, 1, 259.71, -6)"
        gradientUnits="userSpaceOnUse"
      >
        <stop offset="0" stop-color="#f0523c" stop-opacity="0.1" />
        <stop offset="1" stop-color="#f0523c" stop-opacity="0.4" />
      </linearGradient>
      <linearGradient
        id="linear-gradient-14"
        x1="151.45"
        y1="602.12"
        x2="151.45"
        y2="510.98"
        gradientTransform="matrix(-1, 0, 0, 1, 259.71, -24)"
        gradientUnits="userSpaceOnUse"
      >
        <stop offset="0" stop-color="#f0523c" />
        <stop offset="0.51" stop-color="#f3723b" />
        <stop offset="1" stop-color="#f0523c" />
      </linearGradient>
      <linearGradient
        id="linear-gradient-15"
        x1="42.19"
        y1="45.86"
        x2="0"
        y2="45.86"
        gradientTransform="matrix(-1, 0, 0, 1, 260.29, 29.79)"
        gradientUnits="userSpaceOnUse"
      >
        <stop offset="0" stop-color="#2484c6" />
        <stop offset="0.04" stop-color="#2484c6" stop-opacity="0.87" />
        <stop offset="0.1" stop-color="#2484c6" stop-opacity="0.67" />
        <stop offset="0.18" stop-color="#2484c6" stop-opacity="0.49" />
        <stop offset="0.26" stop-color="#2484c6" stop-opacity="0.34" />
        <stop offset="0.35" stop-color="#2484c6" stop-opacity="0.21" />
        <stop offset="0.45" stop-color="#2484c6" stop-opacity="0.12" />
        <stop offset="0.56" stop-color="#2484c6" stop-opacity="0.05" />
        <stop offset="0.71" stop-color="#2484c6" stop-opacity="0.01" />
        <stop offset="1" stop-color="#2484c6" stop-opacity="0" />
      </linearGradient>
      <linearGradient
        id="linear-gradient-16"
        x1="42.19"
        y1="120.57"
        x2="0"
        y2="120.57"
        xlink:href="#linear-gradient-15"
      />
      <linearGradient
        id="linear-gradient-17"
        x1="42.1"
        y1="195.19"
        x2="0"
        y2="195.19"
        xlink:href="#linear-gradient-15"
      />
      <linearGradient
        id="linear-gradient-18"
        x1="42.19"
        y1="269.59"
        x2="0"
        y2="269.59"
        xlink:href="#linear-gradient-15"
      />
      <linearGradient
        id="linear-gradient-19"
        x1="42.44"
        y1="344.43"
        x2="0"
        y2="344.43"
        xlink:href="#linear-gradient-15"
      />
      <linearGradient
        id="linear-gradient-20"
        x1="41.43"
        y1="420.85"
        x2="0"
        y2="420.85"
        xlink:href="#linear-gradient-15"
      />
      <linearGradient
        id="linear-gradient-21"
        x1="42.44"
        y1="494.61"
        x2="0"
        y2="494.61"
        xlink:href="#linear-gradient-15"
      />
      <linearGradient
        id="linear-gradient-22"
        x1="42.44"
        y1="569.32"
        x2="0"
        y2="569.32"
        xlink:href="#linear-gradient-15"
      />
    </defs>
    <polygon
      points="153.4 38.3 196.53 38.3 218.1 75.66 196.53 113.01 153.4 113.01 131.84 75.66 153.4 38.3"
      style="fill: none; stroke-miterlimit: 10; stroke: url(#Fading_Sky)"
    />
    <polygon
      points="153.4 113.01 196.53 113.01 218.1 150.36 196.53 187.71 153.4 187.71 131.84 150.36 153.4 113.01"
      style="fill: none; stroke-miterlimit: 10; stroke: url(#Fading_Sky-2)"
    />
    <polygon
      points="88.14 150.36 131.27 150.36 152.84 187.71 131.27 225.06 88.14 225.06 66.58 187.71 88.14 150.36"
      style="fill: none; stroke-miterlimit: 10; stroke: url(#Fading_Sky-3)"
    />
    <polygon
      points="88.14 225.39 131.27 225.39 152.84 262.74 131.27 300.09 88.14 300.09 66.58 262.74 88.14 225.39"
      style="fill: none; stroke-miterlimit: 10; stroke: url(#Fading_Sky-4)"
    />
    <polygon
      points="153.4 262.03 196.53 262.03 218.1 299.38 196.53 336.74 153.4 336.74 131.84 299.38 153.4 262.03"
      style="fill: none; stroke-miterlimit: 10; stroke: url(#Fading_Sky-5)"
    />
    <polygon
      points="153.15 336.87 196.28 336.87 217.85 374.23 196.28 411.58 153.15 411.58 131.59 374.23 153.15 336.87"
      style="fill: none; stroke-miterlimit: 10; stroke: url(#Fading_Sky-6)"
    />
    <polygon
      points="153.15 411.58 196.28 411.58 217.85 448.93 196.28 486.28 153.15 486.28 131.59 448.93 153.15 411.58"
      style="fill: none; stroke-miterlimit: 10; stroke: url(#Fading_Sky-7)"
    />
    <polygon
      points="87.89 374.23 131.02 374.23 152.59 411.58 131.02 448.93 87.89 448.93 66.33 411.58 87.89 374.23"
      style="fill: none; stroke-miterlimit: 10; stroke: url(#Fading_Sky-8)"
    />
    <polygon
      points="87.89 448.93 131.02 448.93 152.59 486.28 131.02 523.63 87.89 523.63 66.33 486.28 87.89 448.93"
      style="fill: none; stroke-miterlimit: 10; stroke: url(#Fading_Sky-9)"
    />
    <polygon
      points="153.15 487.05 196.28 487.05 217.85 524.41 196.28 561.76 153.15 561.76 131.59 524.41 153.15 487.05"
      style="fill: none; stroke-miterlimit: 10; stroke: url(#Fading_Sky-10)"
    />
    <polygon
      points="153.15 561.76 196.28 561.76 217.85 599.11 196.28 636.46 153.15 636.46 131.59 599.11 153.15 561.76"
      style="fill: none; stroke-miterlimit: 10; stroke: url(#Fading_Sky-11)"
    />
    <polygon
      points="87.89 524.41 131.02 524.41 152.59 561.76 131.02 599.11 87.89 599.11 66.33 561.76 87.89 524.41"
      style="fill: none; stroke-miterlimit: 10; stroke: url(#Fading_Sky-12)"
    />
    <polygon
      points="152.59 636.46 131.02 673.81 87.89 673.81 66.33 636.46 87.89 599.11 131.02 599.11 152.59 636.46"
      style="fill: none; stroke-miterlimit: 10; stroke: url(#Fading_Sky-13)"
    />
    <polygon
      points="24.11 37.38 67.24 37.38 88.8 74.73 67.24 112.08 24.11 112.08 2.54 74.73 24.11 37.38"
      style="fill: none; stroke-miterlimit: 10; stroke: url(#Fading_Sky-14)"
    />
    <polygon
      points="22.8 113.17 65.93 113.17 87.49 150.52 65.93 187.88 22.8 187.88 1.23 150.52 22.8 113.17"
      style="fill: none; stroke-miterlimit: 10; stroke: url(#Fading_Sky-15)"
    />
    <polygon
      points="23.45 187.65 66.58 187.65 88.15 225.01 66.58 262.36 23.45 262.36 1.89 225.01 23.45 187.65"
      style="fill: none; stroke-miterlimit: 10; stroke: url(#Fading_Sky-16)"
    />
    <polygon
      points="22.14 262.14 65.27 262.14 86.84 299.49 65.27 336.84 22.14 336.84 0.58 299.49 22.14 262.14"
      style="fill: none; stroke-miterlimit: 10; stroke: url(#Fading_Sky-17)"
    />
    <polygon
      points="22.8 336.62 65.93 336.62 87.49 373.97 65.93 411.32 22.8 411.32 1.23 373.97 22.8 336.62"
      style="fill: none; stroke-miterlimit: 10; stroke: url(#Fading_Sky-18)"
    />
    <polygon
      points="22.8 411.1 65.93 411.1 87.49 448.45 65.93 485.8 22.8 485.8 1.23 448.45 22.8 411.1"
      style="fill: none; stroke-miterlimit: 10; stroke: url(#Fading_Sky-19)"
    />
    <polygon
      points="23.84 486.05 66.97 486.05 88.53 523.41 66.97 560.76 23.84 560.76 2.27 523.41 23.84 486.05"
      style="fill: none; stroke-miterlimit: 10; stroke: url(#Fading_Sky-20)"
    />
    <polygon
      points="22.53 561.85 65.66 561.85 87.23 599.2 65.66 636.55 22.53 636.55 0.96 599.2 22.53 561.85"
      style="fill: none; stroke-miterlimit: 10; stroke: url(#Fading_Sky-21)"
    />
    <line
      x1="131.92"
      y1="1.01"
      x2="153.49"
      y2="38.36"
      style="fill: none; stroke-miterlimit: 10; stroke: url(#Fading_Sky-22)"
    />
    <line
      x1="66.92"
      y1="37.6"
      x2="88.49"
      y2="0.25"
      style="fill: none; stroke-miterlimit: 10; stroke: url(#Fading_Sky-23)"
    />
    <line
      x1="196.53"
      y1="636.46"
      x2="218.1"
      y2="673.81"
      style="fill: none; stroke-miterlimit: 10; stroke: url(#Fading_Sky-24)"
    />
    <path
      d="M154.54,82.17,132,43.08H86.87L64.31,82.17l22.56,39.08H132Z"
      transform="translate(0.58 29.79)"
      style="fill-opacity: 0.07999999821186066; fill: url(#linear-gradient)"
    />
    <path
      d="M131.57,120.53l22.15-38.36L131.57,43.8H87.28L65.14,82.17l22.14,38.36Z"
      transform="translate(0.58 29.79)"
      style="
        stroke-width: 3px;
        fill: url(#linear-gradient-2);
        stroke: url(#linear-gradient-3);
      "
    />
    <path
      d="M218.42,195.19l-22-38.2H152.28l-22.05,38.2,22.05,38.21h44.09Z"
      transform="translate(0.58 29.79)"
      style="fill-opacity: 0.07999999821186066; fill: url(#linear-gradient-4)"
    />
    <path
      d="M196,232.69l21.64-37.5L196,157.69H152.68L131,195.19l21.64,37.5Z"
      transform="translate(0.58 29.79)"
      style="
        stroke-width: 3px;
        fill: url(#linear-gradient-5);
        stroke: url(#linear-gradient-6);
      "
    />
    <path
      d="M154.93,307,132,267.31H86.22L63.31,307l22.91,39.69H132Z"
      transform="translate(0.58 29.79)"
      style="fill: #fff; fill-opacity: 0.07999999821186066"
    />
    <path
      d="M131.61,346l22.48-39L131.61,268h-45L64.15,307l22.49,39Z"
      transform="translate(0.58 29.79)"
      style="
        stroke-width: 3px;
        fill: url(#linear-gradient-7);
        stroke: url(#linear-gradient-8);
      "
    />
    <path
      d="M219.1,420.85l-22.47-38.93H151.7l-22.47,38.93,22.47,38.94h44.93Z"
      transform="translate(0.58 29.79)"
      style="fill-opacity: 0.07999999821186066; fill: url(#linear-gradient-9)"
    />
    <path
      d="M196.22,459.07l22.06-38.22-22.06-38.21H152.11l-22.06,38.21,22.06,38.22Z"
      transform="translate(0.58 29.79)"
      style="
        stroke-width: 3px;
        fill: url(#linear-gradient-10);
        stroke: url(#linear-gradient-11);
      "
    />
    <path
      d="M152.93,532.55l-22.34-38.71H85.92L63.58,532.55l22.34,38.7h44.67Z"
      transform="translate(0.58 29.79)"
      style="fill-opacity: 0.07999999821186066; fill: url(#linear-gradient-12)"
    />
    <path
      d="M130.18,570.54l21.93-38-21.93-38H86.33l-21.93,38,21.93,38Z"
      transform="translate(0.58 29.79)"
      style="
        stroke-width: 3px;
        fill: url(#linear-gradient-13);
        stroke: url(#linear-gradient-14);
      "
    />
    <line
      x1="218.1"
      y1="75.66"
      x2="260.29"
      y2="75.66"
      style="
        fill: none;
        stroke-miterlimit: 10;
        stroke: url(#linear-gradient-15);
      "
    />
    <line
      x1="218.1"
      y1="150.36"
      x2="260.29"
      y2="150.36"
      style="
        fill: none;
        stroke-miterlimit: 10;
        stroke: url(#linear-gradient-16);
      "
    />
    <line
      x1="218.19"
      y1="224.99"
      x2="260.29"
      y2="224.99"
      style="
        fill: none;
        stroke-miterlimit: 10;
        stroke: url(#linear-gradient-17);
      "
    />
    <line
      x1="218.1"
      y1="299.38"
      x2="260.29"
      y2="299.38"
      style="
        fill: none;
        stroke-miterlimit: 10;
        stroke: url(#linear-gradient-18);
      "
    />
    <line
      x1="217.85"
      y1="374.22"
      x2="260.29"
      y2="374.22"
      style="
        fill: none;
        stroke-miterlimit: 10;
        stroke: url(#linear-gradient-19);
      "
    />
    <line
      x1="218.86"
      y1="450.65"
      x2="260.29"
      y2="450.65"
      style="
        fill: none;
        stroke-miterlimit: 10;
        stroke: url(#linear-gradient-20);
      "
    />
    <line
      x1="217.85"
      y1="524.41"
      x2="260.29"
      y2="524.41"
      style="
        fill: none;
        stroke-miterlimit: 10;
        stroke: url(#linear-gradient-21);
      "
    />
    <line
      x1="217.85"
      y1="599.11"
      x2="260.29"
      y2="599.11"
      style="
        fill: none;
        stroke-miterlimit: 10;
        stroke: url(#linear-gradient-22);
      "
    />
    <text
      transform="translate(95.73 104.41)"
      style="
        isolation: isolate;
        font-size: 18.937744140625px;
        fill: #fff;
        font-family: ArialMT, Arial;
      "
    >
      Q1
    </text>
    <text
      transform="translate(88.09 128.7)"
      style="
        isolation: isolate;
        font-size: 18.937744140625px;
        fill: #fff;
        font-family: ArialMT, Arial;
      "
    >
      2022
    </text>
    <text
      transform="translate(161.33 221.86)"
      style="
        isolation: isolate;
        font-size: 18.937744140625px;
        fill: #fff;
        font-family: ArialMT, Arial;
      "
    >
      Q2
    </text>
    <text
      transform="translate(153.68 246.15)"
      style="
        isolation: isolate;
        font-size: 18.937744140625px;
        fill: #fff;
        font-family: ArialMT, Arial;
      "
    >
      2022
    </text>
    <text
      transform="translate(96.37 331.61)"
      style="
        isolation: isolate;
        font-size: 18.937744140625px;
        fill: #fff;
        font-family: ArialMT, Arial;
      "
    >
      Q3
    </text>
    <text
      transform="translate(88.72 355.89)"
      style="
        isolation: isolate;
        font-size: 18.937744140625px;
        fill: #fff;
        font-family: ArialMT, Arial;
      "
    >
      2022
    </text>
    <text
      transform="translate(160.49 442.5)"
      style="
        isolation: isolate;
        font-size: 18.937744140625px;
        fill: #fff;
        font-family: ArialMT, Arial;
      "
    >
      Q4
    </text>
    <text
      transform="translate(152.85 466.79)"
      style="
        isolation: isolate;
        font-size: 18.937744140625px;
        fill: #fff;
        font-family: ArialMT, Arial;
      "
    >
      2022
    </text>
    <text
      transform="translate(95.37 554.98)"
      style="
        isolation: isolate;
        font-size: 18.937744140625px;
        fill: #fff;
        font-family: ArialMT, Arial;
      "
    >
      Q5
    </text>
    <text
      transform="translate(87.72 579.27)"
      style="
        isolation: isolate;
        font-size: 18.937744140625px;
        fill: #fff;
        font-family: ArialMT, Arial;
      "
    >
      2022
    </text>
  </svg>
</template>


<style scoped>
</style>