export { default as Features } from '../..\\components\\Features.vue'
export { default as Footer } from '../..\\components\\Footer.vue'
export { default as NavBar } from '../..\\components\\NavBar.vue'
export { default as OurPartners } from '../..\\components\\OurPartners.vue'
export { default as SocialBtn } from '../..\\components\\SocialBtn.vue'
export { default as Subscribe } from '../..\\components\\Subscribe.vue'
export { default as ThemeSwitch } from '../..\\components\\ThemeSwitch.vue'
export { default as TierStructure } from '../..\\components\\TierStructure.vue'
export { default as Blog } from '../..\\components\\blog\\Blog.vue'
export { default as BlogBox } from '../..\\components\\blog\\BlogBox.vue'
export { default as Graphics } from '../..\\components\\graphics\\Graphics.vue'
export { default as GraphicsLinee } from '../..\\components\\graphics\\Linee.vue'
export { default as GraphicsRectangle } from '../..\\components\\graphics\\Rectangle.vue'
export { default as HowWorks } from '../..\\components\\how-works\\HowWorks.vue'
export { default as LaunchpadColoredGlassBox } from '../..\\components\\launchpad\\ColoredGlassBox.vue'
export { default as Launchpad } from '../..\\components\\launchpad\\Launchpad.vue'
export { default as Roadmap } from '../..\\components\\roadmap\\Roadmap.vue'
export { default as HowWorksShapesCircle } from '../..\\components\\how-works\\shapes\\circle.vue'
export { default as HowWorksShapesGuarunteed } from '../..\\components\\how-works\\shapes\\guarunteed.vue'
export { default as HowWorksShapesLine1 } from '../..\\components\\how-works\\shapes\\line-1.vue'
export { default as HowWorksShapesLine2 } from '../..\\components\\how-works\\shapes\\line-2.vue'
export { default as HowWorksShapesLine3 } from '../..\\components\\how-works\\shapes\\line-3.vue'
export { default as HowWorksShapesLine4 } from '../..\\components\\how-works\\shapes\\line-4.vue'
export { default as HowWorksShapesNewSystem } from '../..\\components\\how-works\\shapes\\new-system.vue'
export { default as HowWorksShapesProcess } from '../..\\components\\how-works\\shapes\\process.vue'
export { default as HowWorksShapesSmLine1 } from '../..\\components\\how-works\\shapes\\sm-line-1.vue'
export { default as HowWorksShapesSmLine2 } from '../..\\components\\how-works\\shapes\\sm-line-2.vue'
export { default as HowWorksShapesSmLine3 } from '../..\\components\\how-works\\shapes\\sm-line-3.vue'
export { default as HowWorksShapesStack } from '../..\\components\\how-works\\shapes\\stack.vue'
export { default as RoadmapShapesHexagons } from '../..\\components\\roadmap\\shapes\\Hexagons.vue'
export { default as RoadmapShapesMoon } from '../..\\components\\roadmap\\shapes\\Moon.vue'
export { default as RoadmapShapesSmHexagons } from '../..\\components\\roadmap\\shapes\\SmHexagons.vue'

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}
