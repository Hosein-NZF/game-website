# Discovered Components

This is an auto-generated list of components discovered by [nuxt/components](https://github.com/nuxt/components).

You can directly use them in pages and other components without the need to import them.

**Tip:** If a component is conditionally rendered with `v-if` and is big, it is better to use `Lazy` or `lazy-` prefix to lazy load.

- `<Features>` | `<features>` (components/Features.vue)
- `<Footer>` | `<footer>` (components/Footer.vue)
- `<NavBar>` | `<nav-bar>` (components/NavBar.vue)
- `<OurPartners>` | `<our-partners>` (components/OurPartners.vue)
- `<SocialBtn>` | `<social-btn>` (components/SocialBtn.vue)
- `<Subscribe>` | `<subscribe>` (components/Subscribe.vue)
- `<ThemeSwitch>` | `<theme-switch>` (components/ThemeSwitch.vue)
- `<TierStructure>` | `<tier-structure>` (components/TierStructure.vue)
- `<Blog>` | `<blog>` (components/blog/Blog.vue)
- `<BlogBox>` | `<blog-box>` (components/blog/BlogBox.vue)
- `<Graphics>` | `<graphics>` (components/graphics/Graphics.vue)
- `<GraphicsLinee>` | `<graphics-linee>` (components/graphics/Linee.vue)
- `<GraphicsRectangle>` | `<graphics-rectangle>` (components/graphics/Rectangle.vue)
- `<HowWorks>` | `<how-works>` (components/how-works/HowWorks.vue)
- `<LaunchpadColoredGlassBox>` | `<launchpad-colored-glass-box>` (components/launchpad/ColoredGlassBox.vue)
- `<Launchpad>` | `<launchpad>` (components/launchpad/Launchpad.vue)
- `<Roadmap>` | `<roadmap>` (components/roadmap/Roadmap.vue)
- `<HowWorksShapesCircle>` | `<how-works-shapes-circle>` (components/how-works/shapes/circle.vue)
- `<HowWorksShapesGuarunteed>` | `<how-works-shapes-guarunteed>` (components/how-works/shapes/guarunteed.vue)
- `<HowWorksShapesLine1>` | `<how-works-shapes-line1>` (components/how-works/shapes/line-1.vue)
- `<HowWorksShapesLine2>` | `<how-works-shapes-line2>` (components/how-works/shapes/line-2.vue)
- `<HowWorksShapesLine3>` | `<how-works-shapes-line3>` (components/how-works/shapes/line-3.vue)
- `<HowWorksShapesLine4>` | `<how-works-shapes-line4>` (components/how-works/shapes/line-4.vue)
- `<HowWorksShapesNewSystem>` | `<how-works-shapes-new-system>` (components/how-works/shapes/new-system.vue)
- `<HowWorksShapesProcess>` | `<how-works-shapes-process>` (components/how-works/shapes/process.vue)
- `<HowWorksShapesSmLine1>` | `<how-works-shapes-sm-line1>` (components/how-works/shapes/sm-line-1.vue)
- `<HowWorksShapesSmLine2>` | `<how-works-shapes-sm-line2>` (components/how-works/shapes/sm-line-2.vue)
- `<HowWorksShapesSmLine3>` | `<how-works-shapes-sm-line3>` (components/how-works/shapes/sm-line-3.vue)
- `<HowWorksShapesStack>` | `<how-works-shapes-stack>` (components/how-works/shapes/stack.vue)
- `<RoadmapShapesHexagons>` | `<roadmap-shapes-hexagons>` (components/roadmap/shapes/Hexagons.vue)
- `<RoadmapShapesMoon>` | `<roadmap-shapes-moon>` (components/roadmap/shapes/Moon.vue)
- `<RoadmapShapesSmHexagons>` | `<roadmap-shapes-sm-hexagons>` (components/roadmap/shapes/SmHexagons.vue)
